ESOFasterTravel v1.2.2
By XanDDemoX

FasterTravel adds two new tabs to the default world map information/navigation control and suggests approximately the closest known wayshrines to your current quest objectives.

Please note: I am currently working on support for the Transitus shrine network in Cyrodiil so they will not appear yet :)

Wayshrines

- Displays the closest known wayshrine to your quests by marking them with the quest's icon from the map (when it is possible to obtain the data :)).
- Displays quest objective tooltips when the mouse is over quest icons.
- Fast travel to or recall a recently used wayshrine
- Fast travel to or recall a wayshrine in the current zone
- Fast travel to or recall a wayshrine in another
- All fast travels and recalls use the appropriate standard confirmation dialog.

Players

- Teleport to players in your group
- Teleport to players on your friends list
- Teleport to zones using players on your friends list, in your group or guild
- Teleport to players in your any of your guilds

Installation

Extract or copy the "FasterTravel" folder into your addons folder:

Place the "FasterTravel" folder in your addons folder:

"Documents\Elder Scrolls Online\live\Addons"

"Documents\Elder Scrolls Online\liveeu\Addons"

For example:

"Documents\Elder Scrolls Online\live\Addons\FasterTravel"

"Documents\Elder Scrolls Online\liveeu\Addons\FasterTravel"

Usage

Use a wayshrine or open the world map.

Slash Commands

/goto zoneName - attempts to teleport to a zone via a player.
/goto @PlayerName - attempts to teleport to a player.
/goto CharacterName - attempts to teleport a player using their character name. (only works in a group)


DISCLAIMER
THIS ADDON IS NOT CREATED BY, ENDORSED, MAINTAINED OR SUPPORTED BY ZENIMAX OR ANY OF ITS AFFLIATES.