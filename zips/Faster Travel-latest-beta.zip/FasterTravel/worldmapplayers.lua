
--xml backend

local MapPlayers = FasterTravel_WorldMapPlayers
FasterTravel.WorldMapInfoControl.Initialise(MapPlayers)